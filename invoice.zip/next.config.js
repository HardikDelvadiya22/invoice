module.exports = {
  reactStrictMode: true,
  env:{
    baseUrl:"https://fst-invoice.herokuapp.com/api"
  }
}
